﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace StudentBlazorTG.Migrations
{
    public partial class initial_migration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Students",
                columns: table => new
                {
                    StudentId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    FirstName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    LastName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CourseCode = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CourseTitle = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Students", x => x.StudentId);
                });

            migrationBuilder.InsertData(
                table: "Students",
                columns: new[] { "StudentId", "CourseCode", "CourseTitle", "Email", "FirstName", "LastName" },
                values: new object[] { "9537a82a-47f6-4363-9945-8906148e5c84", "STY 1001", "Software Engineering Concepts", "kinjal.patel@cambriancollege.ca", "Kinjal", "Patel" });

            migrationBuilder.InsertData(
                table: "Students",
                columns: new[] { "StudentId", "CourseCode", "CourseTitle", "Email", "FirstName", "LastName" },
                values: new object[] { "e55bf3d9-65d6-4177-bc33-b9dda18412f1", "STY 1001", "Software Engineering Concepts", "melina.satyal@cambriancollege.ca", "Melina", "Satyal" });

            migrationBuilder.InsertData(
                table: "Students",
                columns: new[] { "StudentId", "CourseCode", "CourseTitle", "Email", "FirstName", "LastName" },
                values: new object[] { "c2a12f31-4cd6-4c35-bd74-3061821007b8", "STY 1001", "Software Engineering Concepts", "kunal.bhuva@cambriancollege.ca", "Kunal", "Bhuva" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Students");
        }
    }
}
