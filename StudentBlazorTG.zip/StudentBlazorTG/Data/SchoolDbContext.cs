using System;
using Microsoft.EntityFrameworkCore;

namespace ServerBlazorEF.Models
{
    public class SchoolDbContext : DbContext
    {
        public DbSet<Student> Students { get; set; }

        public SchoolDbContext(DbContextOptions<SchoolDbContext> options) : base(options) { }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            builder.Entity<Student>().HasData(
              new
              {
                  StudentId = Guid.NewGuid().ToString(),
                  FirstName = "Kinjal",
                  LastName = "Patel",
                  Email = "patelkinju2526@gmail.com",
                  CourseCode = "STY 1001",
                  CourseTitle = "Software Engineering Concepts"
              },
              new
              {
                  StudentId = Guid.NewGuid().ToString(),
                  FirstName = "Melina",
                  LastName = "Satyal",
                  Email = "melinasatyal@gmail.com",
                  CourseCode = "STY 1001",
                  CourseTitle = "Software Engineering Concepts"

              },
              new
              {
                  StudentId = Guid.NewGuid().ToString(),
                  FirstName = "Kunal",
                  LastName = "Bhuva",
                  Email = "kunalnareshbhuva@gmail.com",
                  CourseCode = "STY 1001",
                  CourseTitle = "Software Engineering Concepts"

              }
              
              
            );
        }
    }
}